"use strict";

/*
 * School Management System Frontend
 *
 * HTML / JavaScript
 *        ↓
 * Spring Boot REST controllers
 *        ↓
 * Spring Data JPA
 *        ↓
 * MySQL school_management
 *
 * IMPORTANT:
 * Database passwords must never be placed in this file.
 */


const modules = [

    /* ============================================================
       STUDENTS
       ============================================================ */

    {
        key: "students",

        group: "People",

        icon: "S",

        title: "Students",

        singular: "Student",

        description:
            "Register and manage student details and parent contact information.",

        endpoint:
            "/api/students",

        idField:
            "studentId",

        fields: [

            field(
                "studentId",
                "Student ID",
                "text",
                true,
                {
                    placeholder: "S002",
                    maxLength: 50
                }
            ),

            field(
                "studentName",
                "Student name",
                "text",
                true,
                {
                    maxLength: 120
                }
            ),

            field(
                "studentAddress",
                "Student address",
                "textarea",
                true,
                {
                    maxLength: 250,
                    fullWidth: true
                }
            ),

            field(
                "birthday",
                "Birthday",
                "date",
                true
            ),

            field(
                "parentName",
                "Parent / guardian name",
                "text",
                false,
                {
                    maxLength: 120
                }
            ),

            field(
                "parentContactNo",
                "Parent contact number",
                "tel",
                false,
                {
                    maxLength: 30,

                    pattern:
                        "[0-9+()\\- ]{7,30}",

                    hint:
                        "Use only numbers, spaces, +, -, and parentheses."
                }
            )
        ]
    },


    /* ============================================================
       TEACHERS
       ============================================================ */

    {
        key: "teachers",

        group: "People",

        icon: "T",

        title: "Teachers",

        singular: "Teacher",

        description:
            "Store teacher identity and contact details.",

        endpoint:
            "/api/teachers",

        idField:
            "teacherId",

        fields: [

            field(
                "teacherId",
                "Teacher ID",
                "text",
                true,
                {
                    placeholder: "T001",
                    maxLength: 50
                }
            ),

            field(
                "teacherName",
                "Teacher name",
                "text",
                true,
                {
                    maxLength: 120
                }
            ),

            field(
                "nic",
                "NIC",
                "text",
                true,
                {
                    maxLength: 30
                }
            ),

            field(
                "address",
                "Address",
                "textarea",
                false,
                {
                    maxLength: 250,
                    fullWidth: true
                }
            )
        ]
    },


    /* ============================================================
       STUDENT GRADES
       ============================================================ */

    {
        key:
            "grades",

        group:
            "Students",

        icon:
            "G",

        title:
            "Student Grades",

        singular:
            "Student grade",

        description:
            "Assign a current grade/class value to a student record.",

        endpoint:
            "/api/grades",

        idField:
            "studentId",

        fields: [

            field(
                "studentId",
                "Student ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "grade",
                "Grade",
                "text",
                true,
                {
                    placeholder: "10",
                    maxLength: 30
                }
            )
        ]
    },


    /* ============================================================
       STUDENT PROFILES
       ============================================================ */

    {
        key:
            "studentProfiles",

        group:
            "Students",

        icon:
            "P",

        title:
            "Student Profiles",

        singular:
            "Student profile",

        description:
            "Maintain a student's profile, achievements, behaviour and average marks.",

        endpoint:
            "/api/student-profiles",

        idField:
            "studentId",

        fields: [

            field(
                "studentId",
                "Student ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "studentName",
                "Student name",
                "text",
                true,
                {
                    maxLength: 120
                }
            ),

            field(
                "studentBirthDate",
                "Birth date",
                "date",
                false
            ),

            field(
                "studentAddress",
                "Address",
                "textarea",
                false,
                {
                    maxLength: 250,
                    fullWidth: true
                }
            ),

            field(
                "achievements",
                "Achievements",
                "textarea",
                false,
                {
                    maxLength: 1000,
                    fullWidth: true
                }
            ),

            field(
                "behaviour",
                "Behaviour",
                "textarea",
                false,
                {
                    maxLength: 1000,
                    fullWidth: true
                }
            ),

            field(
                "averageMarks",
                "Average marks",
                "number",
                false,
                {
                    min: 0,
                    max: 100,
                    step: "0.01"
                }
            )
        ]
    },


    /* ============================================================
       NON ACADEMIC STAFF
       ============================================================ */

    {
        key:
            "nonAcademic",

        group:
            "People",

        icon:
            "N",

        title:
            "Non-Academic Staff",

        singular:
            "Non-academic employee",

        description:
            "Manage basic non-academic employee records.",

        endpoint:
            "/api/non-academic",

        idField:
            "employeeId",

        fields: [

            field(
                "employeeId",
                "Employee ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "employeeName",
                "Employee name",
                "text",
                true,
                {
                    maxLength: 120
                }
            )
        ]
    },


    /* ============================================================
       PHYSICAL PROPERTIES
       ============================================================ */

    {
        key:
            "properties",

        group:
            "Resources",

        icon:
            "R",

        title:
            "Physical Properties",

        singular:
            "Property",

        description:
            "Track school physical property records.",

        endpoint:
            "/api/properties",

        idField:
            "propertyId",

        fields: [

            field(
                "propertyId",
                "Property ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "propertyName",
                "Property name",
                "text",
                true,
                {
                    maxLength: 120
                }
            )
        ]
    },


    /* ============================================================
       ATTENDANCE
       ============================================================ */

    {
        key:
            "attendance",

        group:
            "Academic",

        icon:
            "A",

        title:
            "Attendance",

        singular:
            "Attendance record",

        description:
            "Store attendance entries for students by date, class and time.",

        endpoint:
            "/api/attendance",

        idField:
            "attendanceId",

        autoId:
            true,

        fields: [

            field(
                "attendanceId",
                "Attendance ID",
                "number",
                false,
                {
                    readOnly: true
                }
            ),

            field(
                "studentId",
                "Student ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "date",
                "Date",
                "date",
                true
            ),

            field(
                "className",
                "Class / grade",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "time",
                "Time",
                "time",
                true
            )
        ]
    },


    /* ============================================================
       TEACHER ASSIGNMENTS
       ============================================================ */

    {
        key:
            "teacherAssignments",

        group:
            "Academic",

        icon:
            "W",

        title:
            "Teacher Assignments",

        singular:
            "Assignment",

        description:
            "Store assignment information and the teacher-provided resource link.",

        endpoint:
            "/api/teacher-assignments",

        idField:
            "assiId",

        fields: [

            field(
                "assiId",
                "Assignment ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "subName",
                "Subject name",
                "text",
                true,
                {
                    maxLength: 120
                }
            ),

            field(
                "date",
                "Date",
                "date",
                true
            ),

            field(
                "link",
                "Assignment link",
                "url",
                false,
                {
                    maxLength: 500,
                    fullWidth: true
                }
            )
        ]
    },


    /* ============================================================
       ASSIGNMENT MARKS
       ============================================================ */

    {
        key:
            "assignmentMarks",

        group:
            "Academic",

        icon:
            "M",

        title:
            "Assignment Marks",

        singular:
            "Assignment mark",

        description:
            "Record marks earned by students for assignments.",

        endpoint:
            "/api/assignment-marks",

        idField:
            "id",

        autoId:
            true,

        fields: [

            field(
                "id",
                "Record ID",
                "number",
                false,
                {
                    readOnly: true
                }
            ),

            field(
                "studentId",
                "Student ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "studentName",
                "Student name",
                "text",
                true,
                {
                    maxLength: 120
                }
            ),

            field(
                "marks",
                "Marks",
                "number",
                true,
                {
                    min: 0,
                    step: "0.01"
                }
            ),

            field(
                "assiId",
                "Assignment ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "date",
                "Date",
                "date",
                true
            )
        ]
    },


    /* ============================================================
       SUBJECT MARKS
       ============================================================ */

    {
        key:
            "subjectMarks",

        group:
            "Academic",

        icon:
            "Q",

        title:
            "Subject Marks",

        singular:
            "Subject mark",

        description:
            "Store marks for a student in a particular subject.",

        endpoint:
            "/api/subject-marks",

        idField:
            "id",

        autoId:
            true,

        fields: [

            field(
                "id",
                "Record ID",
                "number",
                false,
                {
                    readOnly: true
                }
            ),

            field(
                "studentId",
                "Student ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "studentName",
                "Student name",
                "text",
                true,
                {
                    maxLength: 120
                }
            ),

            field(
                "marks",
                "Marks",
                "number",
                true,
                {
                    min: 0,
                    step: "0.01"
                }
            ),

            field(
                "subId",
                "Subject ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "subName",
                "Subject name",
                "text",
                true,
                {
                    maxLength: 120
                }
            )
        ]
    },


    /* ============================================================
       GRADE 1 ADMISSION
       ============================================================ */

    {
        key:
            "admissionGrade1",

        group:
            "Admissions",

        icon:
            "1",

        title:
            "Grade 1 Admissions",

        singular:
            "Grade 1 admission",

        description:
            "Record Grade 1 admission criteria and evaluate the saved admission.",

        endpoint:
            "/api/admissions/grade1",

        idField:
            "admissionId",

        special:
            "grade1",

        fields: [

            field(
                "admissionId",
                "Admission ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "marks",
                "Marks",
                "number",
                false,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "assignDate",
                "Assignment date",
                "date",
                false
            ),

            field(
                "birthDate",
                "Birth date",
                "date",
                true
            ),

            field(
                "distance",
                "Distance from school (km)",
                "number",
                false,
                {
                    min: 0,
                    step: "0.01"
                }
            ),

            field(
                "parentInSchool",
                "Parent is an old student",
                "checkbox",
                false
            ),

            field(
                "siblingInSchool",
                "Sibling studies in school",
                "checkbox",
                false
            ),

            field(
                "parentTeaPrin",
                "Parent is teacher/principal",
                "checkbox",
                false
            ),

            field(
                "parentOfficer",
                "Parent is armed-forces officer",
                "checkbox",
                false
            ),

            field(
                "parentAbroad",
                "Parent works abroad",
                "checkbox",
                false
            )
        ]
    },


    /* ============================================================
       INTERMEDIATE ADMISSION
       ============================================================ */

    {
        key:
            "admissionIntermediate",

        group:
            "Admissions",

        icon:
            "I",

        title:
            "Intermediate Admissions",

        singular:
            "Intermediate admission",

        description:
            "Store grade capacity/cut-off information and run availability or scholarship checks.",

        endpoint:
            "/api/admissions/intermediate",

        idField:
            "admissionId",

        special:
            "intermediate",

        fields: [

            field(
                "admissionId",
                "Admission ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "marks",
                "Marks",
                "number",
                false,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "maxStudentCount",
                "Maximum students per grade",
                "number",
                true,
                {
                    min: 1,
                    step: "1"
                }
            ),

            field(
                "schoolCutOff",
                "School scholarship cut-off",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG2",
                "Current students - Grade 2",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG3",
                "Current students - Grade 3",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG4",
                "Current students - Grade 4",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG5",
                "Current students - Grade 5",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG6",
                "Current students - Grade 6",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG7",
                "Current students - Grade 7",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG8",
                "Current students - Grade 8",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG9",
                "Current students - Grade 9",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "studentsG10",
                "Current students - Grade 10",
                "number",
                true,
                {
                    min: 0,
                    step: "1"
                }
            )
        ]
    },


    /* ============================================================
       A/L ADMISSION
       ============================================================ */

    {
        key:
            "admissionAL",

        group:
            "Admissions",

        icon:
            "L",

        title:
            "A/L Admissions",

        singular:
            "A/L admission",

        description:
            "Record A/L stream criteria and evaluate a saved admission.",

        endpoint:
            "/api/admissions/al",

        idField:
            "admissionId",

        special:
            "al",

        fields: [

            field(
                "admissionId",
                "Admission ID",
                "text",
                true,
                {
                    maxLength: 50
                }
            ),

            field(
                "marks",
                "Marks",
                "number",
                false,
                {
                    min: 0,
                    step: "1"
                }
            ),

            field(
                "stream",
                "Stream",
                "select",
                true,
                {
                    options: [
                        "Science",
                        "Technology",
                        "Commerce",
                        "Arts"
                    ]
                }
            ),

            field(
                "criteriaMet",
                "Required subject criteria met",
                "checkbox",
                false
            )
        ]
    }

];


/* ================================================================
   FIELD CREATION HELPER
   ================================================================ */

function field(
    name,
    label,
    type,
    required,
    options = {}
) {

    return {
        name,
        label,
        type,
        required,
        ...options
    };
}


/* ================================================================
   APPLICATION STATE
   ================================================================ */

const state = {

    currentModule:
        null,

    records:
        [],

    filteredRecords:
        [],

    search:
        "",

    modalMode:
        null,

    modalRecord:
        null,

    lastFocusedElement:
        null

};


/* ================================================================
   HTML ELEMENT REFERENCES
   ================================================================ */

const refs = {

    moduleNav:
        document.getElementById(
            "moduleNav"
        ),

    dashboardView:
        document.getElementById(
            "dashboardView"
        ),

    dashboardCards:
        document.getElementById(
            "dashboardCards"
        ),

    moduleView:
        document.getElementById(
            "moduleView"
        ),

    pageEyebrow:
        document.getElementById(
            "pageEyebrow"
        ),

    pageTitle:
        document.getElementById(
            "pageTitle"
        ),

    moduleHeading:
        document.getElementById(
            "moduleHeading"
        ),

    moduleDescription:
        document.getElementById(
            "moduleDescription"
        ),

    addButton:
        document.getElementById(
            "addButton"
        ),

    refreshButton:
        document.getElementById(
            "refreshButton"
        ),

    searchInput:
        document.getElementById(
            "searchInput"
        ),

    recordCount:
        document.getElementById(
            "recordCount"
        ),

    tableHead:
        document.getElementById(
            "tableHead"
        ),

    tableBody:
        document.getElementById(
            "tableBody"
        ),

    emptyState:
        document.getElementById(
            "emptyState"
        ),

    emptyText:
        document.getElementById(
            "emptyText"
        ),

    messageArea:
        document.getElementById(
            "messageArea"
        ),

    apiStatus:
        document.getElementById(
            "apiStatus"
        ),

    modalBackdrop:
        document.getElementById(
            "modalBackdrop"
        ),

    recordModal:
        document.getElementById(
            "recordModal"
        ),

    modalEyebrow:
        document.getElementById(
            "modalEyebrow"
        ),

    modalTitle:
        document.getElementById(
            "modalTitle"
        ),

    modalBody:
        document.getElementById(
            "modalBody"
        ),

    closeModalButton:
        document.getElementById(
            "closeModalButton"
        ),

    menuButton:
        document.getElementById(
            "menuButton"
        ),

    sidebar:
        document.getElementById(
            "sidebar"
        )

};


/* ================================================================
   START APPLICATION
   ================================================================ */

init();


function init() {

    buildNavigation();

    buildDashboardCards();

    bindGlobalEvents();

    showDashboard();

    refreshDashboardCounts();

}


/* ================================================================
   NAVIGATION
   ================================================================ */

function buildNavigation() {

    refs.moduleNav.replaceChildren();


    const dashboardButton =
        createNavButton(
            "dashboard",
            "⌂",
            "Dashboard"
        );


    dashboardButton.addEventListener(
        "click",
        () => {

            showDashboard();

            closeMobileSidebar();

        }
    );


    refs.moduleNav.append(
        dashboardButton
    );


    let currentGroup =
        null;


    for (
        const module
        of modules
        ) {

        if (
            module.group
            !== currentGroup
        ) {

            currentGroup =
                module.group;


            const label =
                document.createElement(
                    "div"
                );


            label.className =
                "nav-section-label";


            label.textContent =
                currentGroup;


            refs.moduleNav.append(
                label
            );

        }


        const button =
            createNavButton(

                module.key,

                module.icon,

                module.title

            );


        button.addEventListener(
            "click",
            () => {

                openModule(
                    module.key
                );

                closeMobileSidebar();

            }
        );


        refs.moduleNav.append(
            button
        );

    }

}


function createNavButton(
    key,
    icon,
    label
) {

    const button =
        document.createElement(
            "button"
        );


    button.type =
        "button";


    button.className =
        "nav-button";


    button.dataset.navKey =
        key;


    const iconSpan =
        document.createElement(
            "span"
        );


    iconSpan.className =
        "nav-icon";


    iconSpan.setAttribute(
        "aria-hidden",
        "true"
    );


    iconSpan.textContent =
        icon;


    const textSpan =
        document.createElement(
            "span"
        );


    textSpan.textContent =
        label;


    button.append(
        iconSpan,
        textSpan
    );


    return button;

}


/* ================================================================
   DASHBOARD
   ================================================================ */

function buildDashboardCards() {

    refs.dashboardCards
        .replaceChildren();


    for (
        const module
        of modules
        ) {

        const card =
            document.createElement(
                "article"
            );


        card.className =
            "dashboard-card";


        card.dataset.dashboardKey =
            module.key;


        const top =
            document.createElement(
                "div"
            );


        top.className =
            "dashboard-card-top";


        const text =
            document.createElement(
                "div"
            );


        const heading =
            document.createElement(
                "h3"
            );


        heading.textContent =
            module.title;


        const desc =
            document.createElement(
                "p"
            );


        desc.textContent =
            module.description;


        text.append(
            heading,
            desc
        );


        const count =
            document.createElement(
                "div"
            );


        count.className =
            "dashboard-count";


        count.dataset.countFor =
            module.key;


        count.textContent =
            "—";


        count.setAttribute(
            "aria-label",
            `${module.title} record count`
        );


        top.append(
            text,
            count
        );


        const button =
            document.createElement(
                "button"
            );


        button.type =
            "button";


        button.className =
            "button button-secondary";


        button.textContent =
            "Open";


        button.addEventListener(
            "click",
            () =>
                openModule(
                    module.key
                )
        );


        card.append(
            top,
            button
        );


        refs.dashboardCards
            .append(card);

    }

}


/* ================================================================
   GLOBAL EVENTS
   ================================================================ */

function bindGlobalEvents() {

    refs.addButton
        .addEventListener(
            "click",
            () =>
                openFormModal(
                    "create"
                )
        );


    refs.refreshButton
        .addEventListener(
            "click",
            () => {

                if (
                    state.currentModule
                ) {

                    loadCurrentModule();

                }
                else {

                    refreshDashboardCounts();

                }

            }
        );


    refs.searchInput
        .addEventListener(
            "input",
            () => {

                state.search =
                    refs.searchInput
                        .value
                        .trim()
                        .toLowerCase();


                applySearch();

            }
        );


    refs.closeModalButton
        .addEventListener(
            "click",
            closeModal
        );


    refs.modalBackdrop
        .addEventListener(
            "mousedown",
            event => {

                if (
                    event.target
                    === refs.modalBackdrop
                ) {

                    closeModal();

                }

            }
        );


    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape"
                &&
                !refs.modalBackdrop
                    .classList
                    .contains("hidden")
            ) {

                closeModal();

            }


            if (
                event.key === "Tab"
                &&
                !refs.modalBackdrop
                    .classList
                    .contains("hidden")
            ) {

                trapFocus(
                    event
                );

            }

        }
    );


    refs.menuButton
        .addEventListener(
            "click",
            () => {

                const open =
                    refs.sidebar
                        .classList
                        .toggle("open");


                refs.menuButton
                    .setAttribute(
                        "aria-expanded",
                        String(open)
                    );

            }
        );

}


/* ================================================================
   DASHBOARD VIEW
   ================================================================ */

function showDashboard() {

    state.currentModule =
        null;


    state.records =
        [];


    state.filteredRecords =
        [];


    state.search =
        "";


    refs.searchInput.value =
        "";


    refs.dashboardView
        .classList
        .remove("hidden");


    refs.moduleView
        .classList
        .add("hidden");


    refs.pageEyebrow.textContent =
        "Overview";


    refs.pageTitle.textContent =
        "Dashboard";


    setActiveNav(
        "dashboard"
    );


    refreshDashboardCounts();

}


/* ================================================================
   MODULE VIEW
   ================================================================ */

async function openModule(
    key
) {

    const module =
        modules.find(
            item =>
                item.key === key
        );


    if (!module) {

        return;

    }


    state.currentModule =
        module;


    state.search =
        "";


    refs.searchInput.value =
        "";


    refs.dashboardView
        .classList
        .add("hidden");


    refs.moduleView
        .classList
        .remove("hidden");


    refs.pageEyebrow.textContent =
        module.group;


    refs.pageTitle.textContent =
        module.title;


    refs.moduleHeading.textContent =
        module.title;


    refs.moduleDescription.textContent =
        module.description;


    refs.addButton.textContent =
        `Add ${module.singular}`;


    refs.searchInput.placeholder =
        `Search ${module.title.toLowerCase()}…`;


    setActiveNav(
        key
    );


    await loadCurrentModule();

}


function setActiveNav(
    key
) {

    for (
        const button
        of refs.moduleNav
        .querySelectorAll(
            ".nav-button"
        )
        ) {

        button.classList.toggle(
            "active",
            button.dataset.navKey
            === key
        );


        if (
            button.dataset.navKey
            === key
        ) {

            button.setAttribute(
                "aria-current",
                "page"
            );

        }
        else {

            button.removeAttribute(
                "aria-current"
            );

        }

    }

}


/* ================================================================
   LOAD DATA
   ================================================================ */

async function loadCurrentModule() {

    const module =
        state.currentModule;


    if (!module) {

        return;

    }


    showLoadingRow();


    try {

        const data =
            await apiRequest(
                module.endpoint
            );


        state.records =
            Array.isArray(data)
                ? data
                : [];


        setApiStatus(
            true
        );


        applySearch();

    }
    catch (error) {

        state.records =
            [];


        state.filteredRecords =
            [];


        renderTable();


        setApiStatus(
            false
        );


        notify(

            "error",

            "Could not load records",

            error.message

        );

    }

}


/* ================================================================
   SEARCH
   ================================================================ */

function applySearch() {

    if (
        !state.currentModule
    ) {

        return;

    }


    if (
        !state.search
    ) {

        state.filteredRecords =
            [
                ...state.records
            ];

    }
    else {

        state.filteredRecords =
            state.records.filter(
                record => {

                    return state
                        .currentModule
                        .fields
                        .some(
                            f => {

                                const value =
                                    record?.[
                                        f.name
                                        ];


                                return String(
                                    value ?? ""
                                )
                                    .toLowerCase()
                                    .includes(
                                        state.search
                                    );

                            }
                        );

                }
            );

    }


    renderTable();

}


/* ================================================================
   TABLE
   ================================================================ */

function renderTable() {

    const module =
        state.currentModule;


    if (!module) {

        return;

    }


    refs.tableHead
        .replaceChildren();


    refs.tableBody
        .replaceChildren();


    const headerRow =
        document.createElement(
            "tr"
        );


    const visibleFields =
        tableFields(
            module
        );


    for (
        const f
        of visibleFields
        ) {

        const th =
            document.createElement(
                "th"
            );


        th.scope =
            "col";


        th.textContent =
            f.label;


        headerRow.append(
            th
        );

    }


    const actionsTh =
        document.createElement(
            "th"
        );


    actionsTh.scope =
        "col";


    actionsTh.textContent =
        "Actions";


    headerRow.append(
        actionsTh
    );


    refs.tableHead.append(
        headerRow
    );


    refs.recordCount.textContent =
        `${state.filteredRecords.length} ${
            state.filteredRecords.length === 1
                ? "record"
                : "records"
        }`;


    const hasRows =
        state.filteredRecords.length
        > 0;


    refs.emptyState
        .classList
        .toggle(
            "hidden",
            hasRows
        );


    refs.tableHead
        .parentElement
        .classList
        .toggle(
            "hidden",
            !hasRows
        );


    if (!hasRows) {

        refs.emptyText.textContent =

            state.search

                ? "Try a different search term."

                : `Add your first ${
                    module.singular
                        .toLowerCase()
                } to get started.`;


        return;

    }


    for (
        const record
        of state.filteredRecords
        ) {

        const row =
            document.createElement(
                "tr"
            );


        for (
            const f
            of visibleFields
            ) {

            const td =
                document.createElement(
                    "td"
                );


            td.textContent =
                formatValue(
                    record?.[
                        f.name
                        ],
                    f
                );


            row.append(
                td
            );

        }


        const actionTd =
            document.createElement(
                "td"
            );


        actionTd.className =
            "actions-cell";


        const viewButton =
            smallAction(

                "View",

                () =>
                    openDetailModal(
                        record
                    )

            );


        const editButton =
            smallAction(

                "Edit",

                () =>
                    openFormModal(
                        "edit",
                        record
                    )

            );


        const deleteButton =
            smallAction(

                "Delete",

                () =>
                    deleteRecord(
                        record
                    ),

                true

            );


        actionTd.append(

            viewButton,

            editButton,

            deleteButton

        );


        row.append(
            actionTd
        );


        refs.tableBody.append(
            row
        );

    }

}


function tableFields(
    module
) {

    const important =
        module.fields.filter(
            f =>
                !f.fullWidth
                &&
                f.type
                !== "checkbox"
        );


    return important.slice(
        0,
        5
    );

}


function smallAction(
    label,
    handler,
    danger = false
) {

    const button =
        document.createElement(
            "button"
        );


    button.type =
        "button";


    button.className =
        `action-button${
            danger
                ? " danger"
                : ""
        }`;


    button.textContent =
        label;


    button.addEventListener(
        "click",
        handler
    );


    return button;

}


function showLoadingRow() {

    refs.emptyState
        .classList
        .add("hidden");


    refs.tableHead
        .parentElement
        .classList
        .remove("hidden");


    refs.tableHead
        .replaceChildren();


    refs.tableBody
        .replaceChildren();


    const row =
        document.createElement(
            "tr"
        );


    row.className =
        "loading-row";


    const cell =
        document.createElement(
            "td"
        );


    cell.colSpan =
        99;


    cell.textContent =
        "Loading records…";


    row.append(
        cell
    );


    refs.tableBody.append(
        row
    );

}


/* ================================================================
   CREATE / EDIT FORM
   ================================================================ */

function openFormModal(
    mode,
    record = null
) {

    const module =
        state.currentModule;


    if (!module) {

        return;

    }


    state.modalMode =
        mode;


    state.modalRecord =
        record;


    refs.modalEyebrow.textContent =
        module.group;


    refs.modalTitle.textContent =

        mode === "create"

            ? `Add ${module.singular}`

            : `Edit ${module.singular}`;


    refs.modalBody
        .replaceChildren();


    const form =
        document.createElement(
            "form"
        );


    form.className =
        "record-form";


    form.noValidate =
        false;


    const grid =
        document.createElement(
            "div"
        );


    grid.className =
        "form-grid";


    for (
        const f
        of module.fields
        ) {

        if (

            mode === "create"

            &&
            module.autoId

            &&
            f.name
            === module.idField

        ) {

            continue;

        }


        grid.append(

            buildFormField(

                f,

                record,

                mode

            )

        );

    }


    const actions =
        document.createElement(
            "div"
        );


    actions.className =
        "form-actions";


    const cancel =
        document.createElement(
            "button"
        );


    cancel.type =
        "button";


    cancel.className =
        "button button-secondary";


    cancel.textContent =
        "Cancel";


    cancel.addEventListener(
        "click",
        closeModal
    );


    const save =
        document.createElement(
            "button"
        );


    save.type =
        "submit";


    save.className =
        "button button-primary";


    save.textContent =

        mode === "create"

            ? "Save record"

            : "Save changes";


    actions.append(

        cancel,

        save

    );


    form.append(

        grid,

        actions

    );


    form.addEventListener(
        "submit",
        async event => {

            event.preventDefault();


            if (
                !form.reportValidity()
            ) {

                return;

            }


            await saveForm(

                form,

                mode,

                record,

                save

            );

        }
    );


    refs.modalBody.append(
        form
    );


    showModal();

}


/* ================================================================
   CREATE EACH FORM FIELD
   ================================================================ */

function buildFormField(
    f,
    record,
    mode
) {

    const group =
        document.createElement(
            "div"
        );


    group.className =
        `form-group${
            f.fullWidth
                ? " full-width"
                : ""
        }`;


    const label =
        document.createElement(
            "label"
        );


    label.className =
        "form-label";


    label.htmlFor =
        `field-${f.name}`;


    label.textContent =
        f.label;


    if (
        f.required
    ) {

        const required =
            document.createElement(
                "span"
            );


        required.className =
            "required-mark";


        required.textContent =
            " *";


        required.setAttribute(
            "aria-hidden",
            "true"
        );


        label.append(
            required
        );

    }


    let control;


    const value =
        record?.[
            f.name
            ];


    /*
     * Checkbox
     */

    if (
        f.type
        === "checkbox"
    ) {

        const wrapper =
            document.createElement(
                "label"
            );


        wrapper.className =
            "checkbox-row";


        wrapper.htmlFor =
            `field-${f.name}`;


        control =
            document.createElement(
                "input"
            );


        control.type =
            "checkbox";


        control.id =
            `field-${f.name}`;


        control.name =
            f.name;


        control.checked =
            Boolean(
                value
            );


        const text =
            document.createElement(
                "span"
            );


        text.textContent =
            f.label;


        wrapper.append(

            control,

            text

        );


        group.append(
            wrapper
        );


        return group;

    }


    /*
     * Textarea
     */

    if (
        f.type
        === "textarea"
    ) {

        control =
            document.createElement(
                "textarea"
            );

    }

    /*
     * Select box
     */

    else if (
        f.type
        === "select"
    ) {

        control =
            document.createElement(
                "select"
            );


        const blank =
            document.createElement(
                "option"
            );


        blank.value =
            "";


        blank.textContent =
            "Select…";


        control.append(
            blank
        );


        for (
            const optionValue
            of f.options || []
            ) {

            const option =
                document.createElement(
                    "option"
                );


            option.value =
                optionValue;


            option.textContent =
                optionValue;


            control.append(
                option
            );

        }

    }

    /*
     * Standard input
     */

    else {

        control =
            document.createElement(
                "input"
            );


        control.type =
            f.type;

    }


    control.className =
        "form-control";


    control.id =
        `field-${f.name}`;


    control.name =
        f.name;


    control.required =
        Boolean(
            f.required
        );


    if (
        f.placeholder
    ) {

        control.placeholder =
            f.placeholder;

    }


    if (
        f.maxLength
    ) {

        control.maxLength =
            f.maxLength;

    }


    if (
        f.min !== undefined
    ) {

        control.min =
            String(
                f.min
            );

    }


    if (
        f.max !== undefined
    ) {

        control.max =
            String(
                f.max
            );

    }


    if (
        f.step !== undefined
    ) {

        control.step =
            String(
                f.step
            );

    }


    if (
        f.pattern
    ) {

        control.pattern =
            f.pattern;

    }


    /*
     * Primary key cannot be changed
     * when editing an existing record.
     */

    const isIdOnEdit =

        mode === "edit"

        &&
        f.name
        === state.currentModule.idField;


    if (
        f.readOnly
        ||
        isIdOnEdit
    ) {

        control.readOnly =
            true;

    }


    if (
        value !== undefined
        &&
        value !== null
    ) {

        control.value =
            normalizeInputValue(

                value,

                f

            );

    }


    group.append(

        label,

        control

    );


    if (
        f.hint
    ) {

        const hint =
            document.createElement(
                "div"
            );


        hint.className =
            "field-hint";


        hint.textContent =
            f.hint;


        group.append(
            hint
        );

    }


    return group;

}


/* ================================================================
   SAVE FORM
   ================================================================ */

async function saveForm(
    form,
    mode,
    originalRecord,
    saveButton
) {

    const module =
        state.currentModule;


    const payload =
        formToObject(

            form,

            module

        );


    saveButton.disabled =
        true;


    saveButton.textContent =
        "Saving…";


    try {

        /*
         * CREATE
         */

        if (
            mode === "create"
        ) {

            await apiRequest(

                module.endpoint,

                {
                    method:
                        "POST",

                    body:
                        JSON.stringify(
                            payload
                        )
                }

            );


            notify(

                "success",

                `${module.singular} saved`,

                "The new record was saved successfully."

            );

        }

        /*
         * UPDATE
         */

        else {

            const id =
                originalRecord?.[
                    module.idField
                    ];


            await apiRequest(

                `${module.endpoint}/${
                    encodeURIComponent(id)
                }`,

                {
                    method:
                        "PUT",

                    body:
                        JSON.stringify(
                            payload
                        )
                }

            );


            notify(

                "success",

                `${module.singular} updated`,

                "Your changes were saved successfully."

            );

        }


        closeModal();


        await loadCurrentModule();


        updateDashboardCount(

            module.key,

            state.records.length

        );

    }
    catch (error) {

        notify(

            "error",

            "Save failed",

            error.message

        );


        saveButton.disabled =
            false;


        saveButton.textContent =

            mode === "create"

                ? "Save record"

                : "Save changes";

    }

}


/* ================================================================
   CONVERT HTML FORM TO JAVASCRIPT OBJECT
   ================================================================ */

function formToObject(
    form,
    module
) {

    const result =
        {};


    for (
        const f
        of module.fields
        ) {

        const control =
            form.elements
                .namedItem(
                    f.name
                );


        if (
            !control
        ) {

            continue;

        }


        if (
            f.type
            === "checkbox"
        ) {

            result[
                f.name
                ] =
                control.checked;

        }

        else if (
            f.type
            === "number"
        ) {

            result[
                f.name
                ] =

                control.value
                === ""

                    ? null

                    : Number(
                        control.value
                    );

        }

        else {

            result[
                f.name
                ] =
                control.value
                    .trim();

        }

    }


    return result;

}


/* ================================================================
   DETAILS WINDOW
   ================================================================ */

function openDetailModal(
    record
) {

    const module =
        state.currentModule;


    if (
        !module
    ) {

        return;

    }


    state.modalMode =
        "detail";


    state.modalRecord =
        record;


    refs.modalEyebrow.textContent =
        module.group;


    refs.modalTitle.textContent =
        `${module.singular} details`;


    refs.modalBody
        .replaceChildren();


    const grid =
        document.createElement(
            "div"
        );


    grid.className =
        "detail-grid";


    for (
        const f
        of module.fields
        ) {

        const item =
            document.createElement(
                "div"
            );


        item.className =
            "detail-item";


        const label =
            document.createElement(
                "div"
            );


        label.className =
            "detail-label";


        label.textContent =
            f.label;


        const value =
            document.createElement(
                "div"
            );


        value.className =
            "detail-value";


        value.textContent =
            formatValue(

                record?.[
                    f.name
                    ],

                f

            );


        item.append(

            label,

            value

        );


        grid.append(
            item
        );

    }


    refs.modalBody.append(
        grid
    );


    appendSpecialActions(

        module,

        record

    );


    const actions =
        document.createElement(
            "div"
        );


    actions.className =
        "form-actions";


    actions.style.marginTop =
        "18px";


    const close =
        document.createElement(
            "button"
        );


    close.type =
        "button";


    close.className =
        "button button-secondary";


    close.textContent =
        "Close";


    close.addEventListener(
        "click",
        closeModal
    );


    const edit =
        document.createElement(
            "button"
        );


    edit.type =
        "button";


    edit.className =
        "button button-primary";


    edit.textContent =
        "Edit";


    edit.addEventListener(
        "click",
        () =>
            openFormModal(
                "edit",
                record
            )
    );


    actions.append(

        close,

        edit

    );


    refs.modalBody.append(
        actions
    );


    showModal();

}


/* ================================================================
   SPECIAL ADMISSION ACTIONS
   ================================================================ */

function appendSpecialActions(
    module,
    record
) {

    if (
        !module.special
    ) {

        return;

    }


    const section =
        document.createElement(
            "section"
        );


    section.className =
        "special-actions";


    const heading =
        document.createElement(
            "h3"
        );


    heading.textContent =
        "Admission checks";


    section.append(
        heading
    );


    const result =
        document.createElement(
            "div"
        );


    result.className =
        "action-result hidden";


    result.setAttribute(
        "role",
        "status"
    );


    /*
     * Grade 1
     * or
     * A/L
     */

    if (

        module.special
        === "grade1"

        ||

        module.special
        === "al"

    ) {

        const row =
            document.createElement(
                "div"
            );


        row.className =
            "special-action-row";


        const button =
            document.createElement(
                "button"
            );


        button.type =
            "button";


        button.className =
            "button button-secondary";


        button.textContent =

            module.special
            === "grade1"

                ? "Check Grade 1 result"

                : "Check A/L result";


        button.addEventListener(
            "click",
            async () => {

                const id =
                    record[
                        module.idField
                        ];


                const suffix =
                    "/result";


                await runSpecialRequest(

                    `${module.endpoint}/${
                        encodeURIComponent(
                            id
                        )
                    }${suffix}`,

                    result,

                    button

                );

            }
        );


        row.append(
            button
        );


        section.append(
            row
        );

    }


    /*
     * Intermediate admission
     */

    if (
        module.special
        === "intermediate"
    ) {

        /*
         * Grade availability
         */

        const availabilityRow =
            document.createElement(
                "div"
            );


        availabilityRow.className =
            "special-action-row";


        const gradeField =
            compactNumberField(

                "check-grade",

                "Grade (2-10)",

                2,

                10,

                1

            );


        const availabilityButton =
            document.createElement(
                "button"
            );


        availabilityButton.type =
            "button";


        availabilityButton.className =
            "button button-secondary";


        availabilityButton.textContent =
            "Check grade availability";


        availabilityButton
            .addEventListener(
                "click",
                async () => {

                    const gradeInput =
                        gradeField.querySelector(
                            "input"
                        );


                    if (
                        !gradeInput
                            .reportValidity()
                    ) {

                        return;

                    }


                    const id =
                        record[
                            module.idField
                            ];


                    await runSpecialRequest(

                        `${module.endpoint}/${
                            encodeURIComponent(
                                id
                            )
                        }/grade/${
                            encodeURIComponent(
                                gradeInput.value
                            )
                        }/available`,

                        result,

                        availabilityButton

                    );

                }
            );


        availabilityRow.append(

            gradeField,

            availabilityButton

        );


        section.append(
            availabilityRow
        );


        /*
         * Scholarship eligibility
         */

        const scholarshipRow =
            document.createElement(
                "div"
            );


        scholarshipRow.className =
            "special-action-row";


        const markField =
            compactNumberField(

                "check-mark",

                "Scholarship mark",

                0,

                1000,

                1

            );


        const scholarshipButton =
            document.createElement(
                "button"
            );


        scholarshipButton.type =
            "button";


        scholarshipButton.className =
            "button button-secondary";


        scholarshipButton.textContent =
            "Check scholarship eligibility";


        scholarshipButton
            .addEventListener(
                "click",
                async () => {

                    const markInput =
                        markField.querySelector(
                            "input"
                        );


                    if (
                        !markInput
                            .reportValidity()
                    ) {

                        return;

                    }


                    const id =
                        record[
                            module.idField
                            ];


                    await runSpecialRequest(

                        `${module.endpoint}/${
                            encodeURIComponent(
                                id
                            )
                        }/scholarship/${
                            encodeURIComponent(
                                markInput.value
                            )
                        }/eligible`,

                        result,

                        scholarshipButton

                    );

                }
            );


        scholarshipRow.append(

            markField,

            scholarshipButton

        );


        section.append(
            scholarshipRow
        );

    }


    section.append(
        result
    );


    refs.modalBody.append(
        section
    );

}


/* ================================================================
   SMALL NUMBER INPUT
   ================================================================ */

function compactNumberField(
    id,
    labelText,
    min,
    max,
    step
) {

    const group =
        document.createElement(
            "div"
        );


    group.className =
        "form-group";


    const label =
        document.createElement(
            "label"
        );


    label.className =
        "form-label";


    label.htmlFor =
        id;


    label.textContent =
        labelText;


    const input =
        document.createElement(
            "input"
        );


    input.className =
        "form-control";


    input.id =
        id;


    input.type =
        "number";


    input.required =
        true;


    input.min =
        String(min);


    input.max =
        String(max);


    input.step =
        String(step);


    group.append(

        label,

        input

    );


    return group;

}


/* ================================================================
   RUN SPECIAL API REQUEST
   ================================================================ */

async function runSpecialRequest(
    url,
    resultElement,
    button
) {

    const oldText =
        button.textContent;


    button.disabled =
        true;


    button.textContent =
        "Checking…";


    try {

        const data =
            await apiRequest(
                url
            );


        resultElement
            .classList
            .remove("hidden");


        resultElement.textContent =
            stringifyResult(
                data
            );

    }
    catch (error) {

        resultElement
            .classList
            .remove("hidden");


        resultElement.textContent =
            `Error: ${error.message}`;

    }
    finally {

        button.disabled =
            false;


        button.textContent =
            oldText;

    }

}


/* ================================================================
   DELETE RECORD
   ================================================================ */

async function deleteRecord(
    record
) {

    const module =
        state.currentModule;


    if (!module) {

        return;

    }


    const id =
        record?.[
            module.idField
            ];


    const confirmed =
        window.confirm(

            `Delete ${
                module.singular
                    .toLowerCase()
            } "${id}"? This cannot be undone.`

        );


    if (!confirmed) {

        return;

    }


    try {

        await apiRequest(

            `${module.endpoint}/${
                encodeURIComponent(
                    id
                )
            }`,

            {
                method:
                    "DELETE"
            }

        );


        notify(

            "success",

            `${module.singular} deleted`,

            "The record was deleted successfully."

        );


        await loadCurrentModule();


        updateDashboardCount(

            module.key,

            state.records.length

        );

    }
    catch (error) {

        notify(

            "error",

            "Delete failed",

            error.message

        );

    }

}


/* ================================================================
   DASHBOARD COUNTS
   ================================================================ */

async function refreshDashboardCounts() {

    const results =
        await Promise.allSettled(

            modules.map(
                async module => {

                    const data =
                        await apiRequest(
                            module.endpoint
                        );


                    return {

                        key:
                        module.key,

                        count:
                            Array.isArray(
                                data
                            )

                                ? data.length

                                : 0

                    };

                }
            )

        );


    let online =
        false;


    for (
        const result
        of results
        ) {

        if (
            result.status
            === "fulfilled"
        ) {

            online =
                true;


            updateDashboardCount(

                result.value.key,

                result.value.count

            );

        }

    }


    for (
        let i = 0;
        i < results.length;
        i++
    ) {

        if (
            results[i].status
            === "rejected"
        ) {

            updateDashboardCount(

                modules[i].key,

                "!"

            );

        }

    }


    setApiStatus(
        online
    );

}


/* ================================================================
   UPDATE ONE DASHBOARD NUMBER
   ================================================================ */

function updateDashboardCount(
    key,
    count
) {

    const element =
        refs.dashboardCards
            .querySelector(

                `[data-count-for="${
                    CSS.escape(key)
                }"]`

            );


    if (
        element
    ) {

        element.textContent =
            String(
                count
            );

    }

}


/* ================================================================
   API COMMUNICATION
   ================================================================ */

async function apiRequest(
    url,
    options = {}
) {

    const requestOptions = {

        method:
            options.method
            || "GET",

        headers: {

            "Accept":
                "application/json",

            ...(
                options.body

                    ? {
                        "Content-Type":
                            "application/json"
                    }

                    : {}
            ),

            ...(
                options.headers
                || {}
            )

        },

        body:
        options.body

    };


    const response =
        await fetch(

            url,

            requestOptions

        );


    const rawText =
        await response.text();


    const parsed =
        parseResponseBody(

            rawText,

            response.headers.get(
                "content-type"
            )

        );


    if (
        !response.ok
    ) {

        throw new Error(

            extractErrorMessage(

                parsed,

                response.status,

                response.statusText

            )

        );

    }


    return parsed;

}


/* ================================================================
   API RESPONSE PARSING
   ================================================================ */

function parseResponseBody(
    text,
    contentType
) {

    if (
        !text
    ) {

        return null;

    }


    const looksJson =

        (
            contentType
            || ""
        )
            .includes(
                "json"
            )

        ||

        /^[\[{]/
            .test(
                text.trim()
            );


    if (
        looksJson
    ) {

        try {

            return JSON.parse(
                text
            );

        }
        catch (_) {

            return text;

        }

    }


    return text;

}


/* ================================================================
   API ERROR HANDLING
   ================================================================ */

function extractErrorMessage(
    data,
    status,
    statusText
) {

    if (

        typeof data
        === "string"

        &&
        data.trim()

    ) {

        return `${status}: ${
            data.trim()
        }`;

    }


    if (

        data

        &&
        typeof data
        === "object"

    ) {

        return (

            data.message

            ||

            data.error

            ||

            data.detail

            ||

            `${status}: ${statusText}`

        );

    }


    return `${status}: ${
        statusText
        || "Request failed"
    }`;

}


/* ================================================================
   DISPLAY VALUES SAFELY
   ================================================================ */

function formatValue(
    value,
    f
) {

    if (
        f.type
        === "checkbox"
    ) {

        return value
            ? "Yes"
            : "No";

    }


    if (

        value === null

        ||

        value === undefined

        ||

        value === ""

    ) {

        return "—";

    }


    return String(
        value
    );

}


/* ================================================================
   NORMALIZE VALUES FOR HTML INPUTS
   ================================================================ */

function normalizeInputValue(
    value,
    f
) {

    if (

        value === null

        ||

        value === undefined

    ) {

        return "";

    }


    if (

        f.type
        === "date"

        &&

        typeof value
        === "string"

    ) {

        return value.slice(
            0,
            10
        );

    }


    if (

        f.type
        === "time"

        &&

        typeof value
        === "string"

    ) {

        return value.slice(
            0,
            5
        );

    }


    return String(
        value
    );

}


/* ================================================================
   DISPLAY SPECIAL API RESULTS
   ================================================================ */

function stringifyResult(
    data
) {

    if (

        data === null

        ||

        data === undefined

    ) {

        return "Request completed successfully.";

    }


    if (
        typeof data
        === "string"
    ) {

        return data;

    }


    if (

        typeof data
        === "boolean"

        ||

        typeof data
        === "number"

    ) {

        return String(
            data
        );

    }


    try {

        return JSON.stringify(

            data,

            null,

            2

        );

    }
    catch (_) {

        return String(
            data
        );

    }

}


/* ================================================================
   API STATUS
   ================================================================ */

function setApiStatus(
    online
) {

    refs.apiStatus
        .classList
        .remove(

            "status-checking",

            "status-online",

            "status-offline"

        );


    if (
        online
    ) {

        refs.apiStatus
            .classList
            .add(
                "status-online"
            );


        refs.apiStatus.textContent =
            "API connected";

    }
    else {

        refs.apiStatus
            .classList
            .add(
                "status-offline"
            );


        refs.apiStatus.textContent =
            "API unavailable";

    }

}


/* ================================================================
   NOTIFICATION
   ================================================================ */

function notify(
    type,
    title,
    message
) {

    const toast =
        document.createElement(
            "div"
        );


    toast.className =
        `toast toast-${type}`;


    const body =
        document.createElement(
            "div"
        );


    const titleElement =
        document.createElement(
            "div"
        );


    titleElement.className =
        "toast-title";


    titleElement.textContent =
        title;


    const textElement =
        document.createElement(
            "div"
        );


    textElement.className =
        "toast-text";


    textElement.textContent =
        message;


    body.append(

        titleElement,

        textElement

    );


    const close =
        document.createElement(
            "button"
        );


    close.type =
        "button";


    close.className =
        "toast-close";


    close.setAttribute(
        "aria-label",
        "Dismiss message"
    );


    close.textContent =
        "×";


    close.addEventListener(
        "click",
        () =>
            toast.remove()
    );


    toast.append(

        body,

        close

    );


    refs.messageArea.append(
        toast
    );


    window.setTimeout(

        () =>
            toast.remove(),

        6500

    );

}


/* ================================================================
   MODAL OPEN
   ================================================================ */

function showModal() {

    state.lastFocusedElement =
        document.activeElement;


    refs.modalBackdrop
        .classList
        .remove(
            "hidden"
        );


    refs.modalBackdrop
        .setAttribute(
            "aria-hidden",
            "false"
        );


    document.body.style.overflow =
        "hidden";


    window.setTimeout(
        () => {

            const focusable =
                refs.recordModal
                    .querySelector(

                        "input, select, textarea, button"

                    );


            (
                focusable

                ||

                refs.closeModalButton
            )
                .focus();

        },

        0
    );

}


/* ================================================================
   MODAL CLOSE
   ================================================================ */

function closeModal() {

    refs.modalBackdrop
        .classList
        .add(
            "hidden"
        );


    refs.modalBackdrop
        .setAttribute(
            "aria-hidden",
            "true"
        );


    refs.modalBody
        .replaceChildren();


    document.body.style.overflow =
        "";


    state.modalMode =
        null;


    state.modalRecord =
        null;


    if (

        state.lastFocusedElement

        &&

        document.contains(
            state.lastFocusedElement
        )

    ) {

        state.lastFocusedElement
            .focus();

    }

}


/* ================================================================
   KEYBOARD FOCUS INSIDE MODAL
   ================================================================ */

function trapFocus(
    event
) {

    const focusables =
        [
            ...refs.recordModal
                .querySelectorAll(

                    'button:not([disabled]), ' +
                    'input:not([disabled]), ' +
                    'select:not([disabled]), ' +
                    'textarea:not([disabled]), ' +
                    '[href], ' +
                    '[tabindex]:not([tabindex="-1"])'

                )
        ]
            .filter(
                element =>
                    !element.closest(
                        ".hidden"
                    )
            );


    if (
        focusables.length
        === 0
    ) {

        return;

    }


    const first =
        focusables[0];


    const last =
        focusables[
        focusables.length - 1
            ];


    if (

        event.shiftKey

        &&

        document.activeElement
        === first

    ) {

        event.preventDefault();

        last.focus();

    }

    else if (

        !event.shiftKey

        &&

        document.activeElement
        === last

    ) {

        event.preventDefault();

        first.focus();

    }

}


/* ================================================================
   MOBILE SIDEBAR
   ================================================================ */

function closeMobileSidebar() {

    refs.sidebar
        .classList
        .remove(
            "open"
        );


    refs.menuButton
        .setAttribute(
            "aria-expanded",
            "false"
        );

}
